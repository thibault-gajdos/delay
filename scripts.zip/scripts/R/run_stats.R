## run_stats.R ---------------------------------------------------------------
##
## Every statistical test reported in the note, on the empirical data and on the
## simulated data, in one place.  Python produces the simulations and the event
## extraction; R does the statistics.  Nothing here reprocesses a signal: the
## empirical inputs are the bin means exported in the OSF archive, so that the
## published tables and the ones produced here rest on identical numbers and any
## difference is attributable to the analysis and not to a re-extraction.
##
## USAGE
##   Rscript run_stats.R                 # data only
##   Rscript run_stats.R --with-sim      # also the simulated counts, if present
##
## OUTPUT
##   stats_tables.txt   human-readable tables, one per measure and period
##   stats_tables.tex   the same, as LaTeX, for inclusion in the note
##   stats_results.csv  one row per effect, for any further processing
##
## THE DESIGN
##
## The manuscript analyses each period with duration (2) x coherence (3) x time
## bin (N).  Here the bin factor is replaced by two orthogonal polynomial
## components, and each is analysed as a dependent variable in its own right:
##
##   LEVEL  the mean over bins            -> duration, coherence, duration x coherence
##   LIN    the linear trend, units/s     -> time, and its interactions
##   QUAD   the quadratic component       -> curvature, and its interactions
##
## The three effects computed on LEVEL do not involve the bin factor and are
## therefore arithmetically identical to the published ones; they are recomputed
## as a replication check and reported alongside.  The effects on LIN and QUAD
## replace the manuscript's four time-related effects, at one or two degrees of
## freedom instead of nineteen or thirty-eight.
##
## Two components are tested, not one, and this is prespecified: the linear
## component because the model predicts a monotone ramp during the delay, and the
## quadratic because at least one measure -- mu-beta lateralisation during the
## stimulus -- is visibly non-monotone, rising during the first second and then
## flattening.  A linear contrast alone would report that measure as null, which
## would be a failure of the test rather than an absence of effect.  No higher
## component is tested.
##
## WINDOWS  (manuscript p. 25, lines 516-521)
##   stimulus   0 to 2 s after stimulus onset            20 bins
##   delay      1 to 3 s after stimulus offset           20 bins
##   RS         0 to 0.2 s after response-signal onset    2 bins
##   response   -0.2 to 0 s before the button press       2 bins
##
## The bin numbering differs between the muscle and brain export files: the
## partial-activation files start at bin 0 for the stimulus and bin 10 for the
## delay, the electroencephalographic files are offset by one, at bins 1 and 11.
## These were identified by finding, for each file, the window that reproduces
## all three published bin-independent F values at once, which admits only one
## solution.  Using the wrong window reproduces nothing and gives no clue why.
##
## With two bins the quadratic component does not exist and the linear component
## is the difference between the bins, so for the response-signal and response
## periods the decomposition reduces to the manuscript's own time effect.

source("rmanova.R")

ARCHIVE <- Sys.getenv("ARCHIVE", "/home/claude/data")
SIMDIR  <- Sys.getenv("SIMDIR", "..")
args <- commandArgs(trailingOnly = TRUE)
WITH_SIM <- "--with-sim" %in% args

CELLS <- c("0.3/c00", "0.3/c12", "0.3/c50", "2.0/c00", "2.0/c12", "2.0/c50")

## ---------------------------------------------------------------------------
## input specification: file, bins, and the published F values for the three
## effects that do not involve the bin factor
SPEC <- list(
  list(m = "PMA", per = "stimulus",
       f = file.path(ARCHIVE, "analysis_PMA/data/PMA_rate_stim_JASP.csv"),
       bins = 0:19,  pub = c(13.38, 5.25, 0.312)),
  list(m = "PMA", per = "delay",
       f = file.path(ARCHIVE, "analysis_PMA/data/PMA_rate_delay_JASP.csv"),
       bins = 10:29, pub = c(33.19, 3.36, 3.474)),
  list(m = "PMA", per = "RS",
       f = file.path(ARCHIVE, "analysis_PMA/data/PMA_rate_rs_JASP.csv"),
       bins = 0:1,   pub = c(36.56, 1.159, 0.041)),
  list(m = "PMA", per = "response",
       f = file.path(ARCHIVE, "analysis_PMA/data/PMA_rate_resp_JASP.csv"),
       bins = 1:2,   pub = c(0.011, 0.724, 0.636)),
  list(m = "MBL", per = "stimulus",
       f = file.path(ARCHIVE, "analysis_MBL/data/MBL_stim_JASP.csv"),
       bins = 1:20,  pub = c(2.146, 2.813, 0.755)),
  list(m = "MBL", per = "delay",
       f = file.path(ARCHIVE, "analysis_MBL/data/MBL_delay_JASP.csv"),
       bins = 11:30, pub = c(3.177, 1.257, 1.586)),
  list(m = "MBL", per = "RS",
       f = file.path(ARCHIVE, "analysis_MBL/data/MBL_rs_JASP.csv"),
       bins = 1:2,   pub = c(3.039, 0.160, 1.216)),
  list(m = "MBL", per = "response",
       f = file.path(ARCHIVE, "analysis_MBL/data/MBL_resp_JASP.csv"),
       bins = 1:2,   pub = c(0.006, 0.364, 0.161)),
  list(m = "LRP", per = "stimulus",
       f = file.path(ARCHIVE, "analysis_LRP/data/LRP_stim_JASP.csv"),
       bins = 1:20,  pub = c(0.636, 1.524, 0.391)),
  list(m = "LRP", per = "delay",
       f = file.path(ARCHIVE, "analysis_LRP/data/LRP_delay_JASP.csv"),
       bins = 11:30, pub = c(0.019, 0.44, 0.378)),
  list(m = "LRP", per = "RS",
       f = file.path(ARCHIVE, "analysis_LRP/data/LRP_rs_JASP.csv"),
       bins = 1:2,   pub = c(0.185, 0.252, 0.267)),
  list(m = "LRP", per = "response",
       f = file.path(ARCHIVE, "analysis_LRP/data/LRP_resp_JASP.csv"),
       bins = 0:1,   pub = c(0.400, 0.31, 0.666))
)

## ---------------------------------------------------------------------------
load_cells <- function(f, bins) {
  d <- read.csv(f, check.names = FALSE)
  d <- d[, tolower(names(d)) != "subject", drop = FALSE]
  stems <- unique(sub("bin[0-9]+$", "", names(d)))
  ## order: duration 0.3 then 2.0, coherence 0, 12, 50
  key <- function(s) {
    dur <- as.integer(sub(".*stim([01]).*", "\\1", s))
    coh <- match(sub(".*coh([0-9]+)_$", "\\1", s), c("0", "12", "50"))
    dur * 3 + coh
  }
  stems <- stems[order(sapply(stems, key))]
  n <- nrow(d)
  A <- array(NA_real_, c(n, 6, length(bins)))
  for (i in seq_along(stems))
    A[, i, ] <- as.matrix(d[, paste0(stems[i], "bin", bins)])
  A
}

EFFECTS <- c("duration", "coherence", "time (linear)", "duration x coherence",
             "duration x time (linear)", "coherence x time (linear)",
             "duration x coherence x time (linear)", "time (quadratic)",
             "duration x time (quadratic)", "coherence x time (quadratic)",
             "duration x coherence x time (quadratic)")

## A period whose window contains only one informative bin cannot support a
## profile analysis.  The response period is such a case: a partial activation
## precedes the response burst by definition, and the burst begins on average
## 160 ms before the button press, so the bin from -0.1 to 0 s is empty for every
## participant and every cell, structurally and not empirically.  The level and
## trend scores are then the same number up to a constant -- TREND = -20 x LEVEL
## with two bins of 0.1 s -- and since a repeated-measures analysis is invariant
## under rescaling of the dependent variable, every time-related effect returns
## the F of the corresponding main effect.  Reporting seven effects would be
## reporting three of them twice, and describing them as a temporal profile would
## claim a slope that rests on a single point.  Such periods are analysed on the
## informative bin alone, with three effects.
analyse_level_only <- function(A, label, keep_bin = 1, pub = NULL) {
  n <- dim(A)[1]
  as_cells <- function(M) aperm(array(M, c(n, 3, 2)), c(1, 3, 2))
  Y <- as_cells(A[, , keep_bin])
  e <- rm_twoway(Y)
  res <- list("duration" = e$duration, "coherence" = e$coherence,
              "duration x coherence" = e$interaction)
  attr(res, "label") <- label
  attr(res, "pub") <- pub
  attr(res, "nbin") <- 1
  attr(res, "lin_cells") <- as.vector(t(apply(Y, c(2, 3), mean)))
  attr(res, "cellname") <- "rate by cell"
  res
}

analyse <- function(A, label, pub = NULL) {
  n <- dim(A)[1]; N <- dim(A)[3]
  wl <- slope_weights(N, 0.1)
  ## the six cells are ordered duration-major (0.3/c00 .. 2.0/c50); R fills
  ## arrays column-major, so build as (n, coherence, duration) and permute
  as_cells <- function(M) aperm(array(M, c(n, 3, 2)), c(1, 3, 2))
  LEVEL <- as_cells(apply(A, c(1, 2), mean))
  LIN   <- as_cells(apply(A, c(1, 2), function(y) sum(wl * y)))
  eL <- rm_twoway(LEVEL); eT <- rm_twoway(LIN)
  res <- list(
    "duration"                  = eL$duration,
    "coherence"                 = eL$coherence,
    "time (linear)"             = rm_paired(apply(LIN, 1, mean)),
    "duration x coherence"      = eL$interaction,
    "duration x time (linear)"  = eT$duration,
    "coherence x time (linear)" = eT$coherence,
    "duration x coherence x time (linear)" = eT$interaction)
  if (N > 2) {
    w2 <- poly_weights(N)[, 2]
    QUAD <- as_cells(apply(A, c(1, 2), function(y) sum(w2 * y)))
    eQ <- rm_twoway(QUAD)
    res[["time (quadratic)"]] <- rm_paired(apply(QUAD, 1, mean))
    res[["duration x time (quadratic)"]] <- eQ$duration
    res[["coherence x time (quadratic)"]] <- eQ$coherence
    res[["duration x coherence x time (quadratic)"]] <- eQ$interaction
  }
  attr(res, "label") <- label
  attr(res, "pub") <- pub
  attr(res, "nbin") <- N
  attr(res, "lin_cells") <- as.vector(t(apply(LIN, c(2, 3), mean)))
  res
}

fmt_p <- function(p) if (p < .001) "<.001" else sub("^0", "", sprintf("%.3f", p))

report <- function(res, con) {
  lab <- attr(res, "label"); pub <- attr(res, "pub")
  nb <- attr(res, "nbin")
  cat("\n", strrep("=", 84), "\n", lab,
      if (nb == 1) "   (one informative bin: level analysis only)"
      else sprintf("   (%d bins)", nb), "\n",
      strrep("=", 84), "\n", sep = "", file = con)
  cat(sprintf("%-40s %6s %7s %9s %9s %7s\n",
              "effect", "df1", "df2", "F", "p", "eta2p"), file = con)
  for (k in names(res)) {
    e <- res[[k]]
    cat(sprintf("%-40s %6.2f %7.2f %9.3f %9s %7.3f\n",
                k, e$df1, e$df2, e$F, fmt_p(e$p), e$eta2p), file = con)
  }
  if (!is.null(pub)) {
    got <- c(res$duration$F, res$coherence$F, res$`duration x coherence`$F)
    ok <- all(abs(got - pub) <= pmax(0.004, 0.01 * abs(pub)))
    cat(sprintf("%-40s %s   [%s]\n", "replication of published F",
                paste(sprintf("%.3f", pub), collapse = ", "),
                if (ok) "reproduced" else "DOES NOT REPRODUCE"), file = con)
  }
  cat(sprintf("%-40s %s\n",
              if (is.null(attr(res, "cellname"))) "linear trend by cell"
              else attr(res, "cellname"),
              paste(sprintf("%s %+.4f", CELLS, attr(res, "lin_cells")),
                    collapse = "  ")), file = con)
}

## ---------------------------------------------------------------------------
con <- file("stats_tables.txt", "w")
rows <- list()
for (s in SPEC) {
  if (!file.exists(s$f)) { cat("missing:", s$f, "\n", file = con); next }
  A <- load_cells(s$f, s$bins)
  ## detect a structurally empty bin and drop to a level-only analysis
  empty <- apply(A, 3, function(z) all(z == 0))
  if (length(s$bins) == 2 && any(empty)) {
    r <- analyse_level_only(A, sprintf("%s, %s period", s$m, s$per),
                            keep_bin = which(!empty)[1], pub = s$pub)
  } else {
    r <- analyse(A, sprintf("%s, %s period", s$m, s$per), s$pub)
  }
  report(r, con)
  for (k in names(r))
    rows[[length(rows) + 1]] <- data.frame(
      measure = s$m, period = s$per, effect = k, df1 = r[[k]]$df1,
      df2 = r[[k]]$df2, F = r[[k]]$F, p = r[[k]]$p, eta2p = r[[k]]$eta2p)
}

## ---------------------------------------------------------------------------
## mu-beta lateralisation, stimulus period, resolved into two halves.
## Reported because the full-window linear component is null while the omnibus
## interaction is not: the coherence dependence of the slope is present in the
## first half and extinguished in the second, which is what saturation of the
## maintained level implies.  The quadratic component above tests the same thing
## without choosing a cut-off, and is the prespecified version; this split is
## descriptive.
sp <- SPEC[[which(sapply(SPEC, function(x) x$m == "MBL" && x$per == "stimulus"))]]
if (file.exists(sp$f)) {
  A <- load_cells(sp$f, sp$bins)
  cat("\n", strrep("=", 84),
      "\nMBL, stimulus period, resolved into two halves (descriptive)\n",
      strrep("=", 84), "\n", sep = "", file = con)
  for (h in list(list(1:10, "first half, 0.05-0.95 s"),
                 list(11:20, "second half, 1.05-1.95 s"),
                 list(1:20, "full window"))) {
    B <- A[, , h[[1]], drop = FALSE]
    wl <- slope_weights(dim(B)[3], 0.1)
    L <- aperm(array(apply(B, c(1, 2), function(y) sum(wl * y)),
                     c(dim(B)[1], 3, 2)), c(1, 3, 2))
    e <- rm_twoway(L); t0 <- rm_paired(apply(L, 1, mean))
    cat(sprintf("  %-26s trend F=%6.2f p=%-7s | x coherence F=%5.2f p=%-7s | x duration F=%5.2f p=%s\n",
                h[[2]], t0$F, fmt_p(t0$p), e$coherence$F, fmt_p(e$coherence$p),
                e$duration$F, fmt_p(e$duration$p)), file = con)
  }
}

## ---------------------------------------------------------------------------
## Poisson analyses of the partial-activation counts, delay window.
## Requires pma_counts.csv, written by the Python side: one row per participant,
## cell and bin, with the raw count and the number of contributing trials.
pf <- file.path(SIMDIR, "pma_counts.csv")
if (file.exists(pf)) {
  d <- read.csv(pf)
  d <- d[d$period == "delay", ]
  tc <- (sort(unique(d$bin)) + 0.5) * 0.1
  tc <- tc - mean(tc)
  cat("\n", strrep("=", 84),
      "\nPoisson analyses of the delay-period counts\n", strrep("=", 84), "\n",
      sep = "", file = con)

  ## two-stage: fit per participant and cell, then analyse the coefficients
  subs <- sort(unique(d$subj)); B1 <- B2 <- matrix(NA_real_, length(subs), 6)
  for (i in seq_along(subs)) for (k in 0:5) {
    z <- d[d$subj == subs[i] & d$cell == k, ]
    z <- z[order(z$bin), ]
    if (nrow(z) < 4 || sum(z$count) < 10) next
    b <- pois_slope_subject(z$count, z$ntrial[1], tc, degree = 2)
    B1[i, k + 1] <- b[2]; B2[i, k + 1] <- 2 * b[3]
  }
  for (nm in c("log-rate slope", "log-rate curvature")) {
    M <- if (nm == "log-rate slope") B1 else B2
    ok <- complete.cases(M)
    X <- aperm(array(M[ok, ], c(sum(ok), 3, 2)), c(1, 3, 2))
    e <- rm_twoway(X); t0 <- rm_paired(rowMeans(M[ok, ]))
    cat(sprintf("\n  %s, two-stage (n = %d)\n", nm, sum(ok)), file = con)
    cat(sprintf("    %-24s %+.4f   F(%.0f,%.0f) = %.2f, p = %s\n",
                "against zero", mean(rowMeans(M[ok, ])), t0$df1, t0$df2, t0$F,
                fmt_p(t0$p)), file = con)
    for (k in names(e))
      cat(sprintf("    %-24s F(%.2f,%.2f) = %.2f, p = %s\n", k,
                  e[[k]]$df1, e[[k]]$df2, e[[k]]$F, fmt_p(e[[k]]$p)), file = con)
  }

  ## one-stage: log-linear model with cluster-robust standard errors
  d$tc <- (d$bin + 0.5) * 0.1 - mean((sort(unique(d$bin)) + 0.5) * 0.1)
  d$durc <- ifelse(d$cell >= 3, 0.5, -0.5)
  d$cohc <- c(0, .12, .5)[(d$cell %% 3) + 1] - mean(c(0, .12, .5))
  d$off <- log(d$ntrial)
  g <- pois_gee(d, count ~ tc * durc + tc * cohc + offset(off), d$subj)
  cat("\n  one-stage log-linear model, cluster-robust standard errors\n", file = con)
  for (i in seq_len(nrow(g)))
    cat(sprintf("    %-24s %+.4f  (se %.4f)  z = %+.2f, p = %s\n",
                g$term[i], g$estimate[i], g$se[i], g$z[i], fmt_p(g$p[i])),
        file = con)
}

## ---------------------------------------------------------------------------
## the same analyses on the simulated counts, if the Python side has written them
if (WITH_SIM) {
  for (mdl in c(1, 2)) {
    sf <- file.path(SIMDIR, sprintf("sim_counts_m%d.csv", mdl))
    if (!file.exists(sf)) next
    d <- read.csv(sf)
    cat("\n", strrep("=", 84), sprintf("\nSIMULATION, Model %d\n", mdl),
        strrep("=", 84), "\n", sep = "", file = con)
    for (per in unique(d$period)) {
      z <- d[d$period == per, ]
      nb <- length(unique(z$bin))
      A <- array(NA_real_, c(length(unique(z$subj)), 6, nb))
      for (i in seq_along(sort(unique(z$subj))))
        for (k in 0:5) {
          y <- z[z$subj == sort(unique(z$subj))[i] & z$cell == k, ]
          A[i, k + 1, ] <- y$rate[order(y$bin)]
        }
      report(analyse(A, sprintf("Model %d, %s period", mdl, per)), con)
    }
  }
}

close(con)
write.csv(do.call(rbind, rows), "stats_results.csv", row.names = FALSE)
cat(readLines("stats_tables.txt"), sep = "\n")
