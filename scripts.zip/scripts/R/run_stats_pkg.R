## run_stats_pkg.R ----------------------------------------------------------
##
## The same analyses as run_stats.R, written with the packages one would normally
## use.  run_stats.R exists because CRAN is unreachable from the analysis
## container; this file is the version to run on a normal machine, and the two
## should agree.  Where they might not, the reason is noted in the comments.
##
##   afex      repeated-measures analysis of variance, Greenhouse-Geisser,
##             effect sizes, and the polynomial split of a within factor
##   emmeans   the trend contrasts, and the two-phase decomposition of the
##             mu-beta stimulus window
##   lme4      the mixed-model versions: Gaussian for the brain measures,
##             Poisson for the partial-activation counts
##   lmerTest  degrees of freedom and p values for the Gaussian mixed models
##   performance  overdispersion check for the Poisson mixed models
##
## USAGE
##   Rscript run_stats_pkg.R                 # data only
##   Rscript run_stats_pkg.R --with-sim      # also the simulated counts
##
## INPUTS
##   the JASP export files of the OSF archive, path in ARCHIVE
##   pma_counts.csv and sim_counts_m{1,2}.csv, written by export_for_R.py
##
## OUTPUTS
##   stats_pkg_tables.txt, stats_pkg_results.csv
##
## -------------------------------------------------------------------------
## WHAT IS BEING TESTED, AND WHY IT IS NOT THE MANUSCRIPT'S ANALYSIS
##
## The manuscript analyses each period with duration (2) x coherence (3) x time
## bin (N), and reports the omnibus F for every effect involving the bin factor.
## An omnibus F on a factor with nineteen degrees of freedom establishes that the
## bins differ, in any of nineteen directions; it does not establish that the rate
## ramps, still less that its slope depends on coherence.  Since the text claims a
## slope, the test has to be a test of slope.
##
## The bin factor is therefore decomposed into orthogonal polynomial components
## and only the first two are examined: the linear, because the model predicts a
## monotone ramp during the delay, and the quadratic, because mu-beta
## lateralisation during the stimulus is visibly non-monotone -- it rises for
## about a second and then flattens -- so that a linear contrast alone would
## report it as null.  This is prespecified, applied identically to all three
## measures, and no higher component is tested.
##
## TWO WAYS TO DO THE DECOMPOSITION, AND WHY ONE IS PREFERRED
##
## (A) Keep the bin factor and split it inside the analysis of variance:
##
##       contrasts(bin) <- contr.poly(nlevels(bin))
##       summary(m, split = list(bin = list(linear = 1, quadratic = 2)))
##
##     This decomposes the numerator but leaves the denominator pooled over all
##     nineteen components.  It is valid only under sphericity, and sphericity is
##     badly violated here: several Greenhouse-Geisser epsilons in the published
##     tables are below 0.2.  It is computed below for comparison, not relied on.
##
## (B) Compute the component as a score per participant and cell, then analyse
##     the score.  Each component then carries its own error term -- participant
##     by linear for the linear component -- and a one-degree-of-freedom contrast
##     needs no sphericity correction at all.  This is what is reported.
##
## The two agree when sphericity holds and diverge when it does not, which is
## precisely the case of interest; (B) is the correct one.

suppressPackageStartupMessages({
  library(afex); library(emmeans); library(dplyr); library(tidyr)
  library(lme4); library(lmerTest)
})
afex_options(emmeans_model = "multivariate", check_contrasts = TRUE)
emm_options(lmer.df = "satterthwaite")

ARCHIVE  <- Sys.getenv("ARCHIVE", "../data")
SIMDIR   <- Sys.getenv("SIMDIR", "..")
WITH_SIM <- "--with-sim" %in% commandArgs(trailingOnly = TRUE)
OUT      <- file("stats_pkg_tables.txt", "w")
say      <- function(...) cat(..., "\n", file = OUT, sep = "")

## ---------------------------------------------------------------------------
## Windows.  The bin numbering is not the same in the two families of files: the
## partial-activation exports start at bin 0 for the stimulus and bin 10 for the
## delay, the electroencephalographic ones are offset by one.  These windows were
## identified by finding, for each file, the one that reproduces all three
## published bin-independent F values simultaneously, which admits a single
## solution.  Using the wrong window reproduces nothing and gives no clue why.
##
## `pub` holds the manuscript's F for duration, coherence and their interaction.
## Those three effects do not involve the bin factor and are therefore
## arithmetically unchanged by the decomposition; they are recomputed as a
## replication check.

SPEC <- tribble(
  ~measure, ~period,     ~file,                                    ~bins,   ~pub,
  "PMA", "stimulus", "analysis_PMA/data/PMA_rate_stim_JASP.csv",   0:19,  c(13.38, 5.25,  0.312),
  "PMA", "delay",    "analysis_PMA/data/PMA_rate_delay_JASP.csv", 10:29,  c(33.19, 3.36,  3.474),
  "PMA", "RS",       "analysis_PMA/data/PMA_rate_rs_JASP.csv",     0:1,   c(36.56, 1.159, 0.041),
  "PMA", "response", "analysis_PMA/data/PMA_rate_resp_JASP.csv",   1:2,   c(NA, NA, NA),
  "MBL", "stimulus", "analysis_MBL/data/MBL_stim_JASP.csv",        1:20,  c(2.146, 2.813, 0.755),
  "MBL", "delay",    "analysis_MBL/data/MBL_delay_JASP.csv",      11:30,  c(3.177, 1.257, 1.586),
  "MBL", "RS",       "analysis_MBL/data/MBL_rs_JASP.csv",          1:2,   c(3.039, 0.160, 1.216),
  "MBL", "response", "analysis_MBL/data/MBL_resp_JASP.csv",        1:2,   c(0.006, 0.364, 0.161),
  "LRP", "stimulus", "analysis_LRP/data/LRP_stim_JASP.csv",        1:20,  c(0.636, 1.524, 0.391),
  "LRP", "delay",    "analysis_LRP/data/LRP_delay_JASP.csv",      11:30,  c(0.019, 0.44,  0.378),
  "LRP", "RS",       "analysis_LRP/data/LRP_rs_JASP.csv",          1:2,   c(0.185, 0.252, 0.267),
  "LRP", "response", "analysis_LRP/data/LRP_resp_JASP.csv",        0:1,   c(0.400, 0.31,  0.666)
)

## ---------------------------------------------------------------------------
## Reading.  The exports are wide: one column per cell and bin, named
## stim{0,1}_coh{0,12,50}_bin{n}.  They are reshaped to long form with duration,
## coherence and bin as factors, which is what afex wants.

read_long <- function(path, bins) {
  d <- read.csv(path, check.names = FALSE)
  names(d)[tolower(names(d)) == "subject"] <- "subj"
  keep <- grepl(paste0("bin(", paste(bins, collapse = "|"), ")$"), names(d))
  d %>%
    select(subj, which(keep)) %>%
    pivot_longer(-subj, names_to = "cellbin", values_to = "y") %>%
    mutate(
      dur = factor(sub("^stim([01])_.*", "\\1", cellbin), levels = c("0", "1"),
                   labels = c("0.3 s", "2 s")),
      coh = factor(sub(".*coh([0-9]+)_.*", "\\1", cellbin), levels = c("0", "12", "50"),
                   labels = c("0%", "12%", "50%")),
      bin = as.integer(sub(".*bin([0-9]+)$", "\\1", cellbin)),
      subj = factor(subj)) %>%
    group_by(subj) %>% mutate(bin = as.integer(factor(bin))) %>% ungroup() %>%
    select(subj, dur, coh, bin, y)
}

## ---------------------------------------------------------------------------
## Scores.  LEVEL is the mean over bins; LIN is the ordinary least-squares slope
## against time, in units per second, obtained from the first polynomial contrast
## rescaled so that the coefficient is a rate of change rather than a normalised
## projection (F and p are unaffected by the rescaling; only the coefficient is);
## QUAD is the second polynomial contrast, which has no natural unit and is
## reported as F and partial eta squared only.

make_scores <- function(d, width = 0.1) {
  nb <- max(d$bin)
  P  <- contr.poly(nb)
  tt <- (seq_len(nb) - (nb + 1) / 2) * width
  wl <- tt / sum(tt^2)                 # slope in units per second
  w2 <- P[, 2]
  d %>% arrange(subj, dur, coh, bin) %>%
    group_by(subj, dur, coh) %>%
    summarise(level = mean(y),
              lin   = sum(wl * y),
              quad  = if (nb > 2) sum(w2 * y) else NA_real_,
              .groups = "drop")
}

## ---------------------------------------------------------------------------
## The seven effects, as two two-way analyses plus a test of the trend against
## zero.  aov_ez applies Greenhouse-Geisser to the three-level factor; the
## two-level factor and the intercept test need no correction.

analyse_period <- function(d, label, pub = NULL) {
  s  <- make_scores(d)
  nb <- max(d$bin)

  ## a period whose window holds a single informative bin cannot support a
  ## profile analysis.  In the response period the bin from -0.1 to 0 s is
  ## exactly zero for every participant and cell, because a partial activation
  ## precedes the response burst by definition and the burst begins about 160 ms
  ## before the press.  LEVEL and LIN are then the same number up to a constant,
  ## a repeated-measures analysis is invariant under rescaling of the dependent
  ## variable, and every time-related effect returns the F of the corresponding
  ## main effect: seven effects of which three are reported twice.  Such periods
  ## are analysed on the informative bin alone.
  empty <- d %>% group_by(bin) %>% summarise(z = all(y == 0)) %>% pull(z)
  if (nb == 2 && any(empty)) {
    k <- which(!empty)[1]
    s1 <- d %>% filter(bin == k) %>% select(subj, dur, coh, y)
    a <- aov_ez("subj", "y", s1, within = c("dur", "coh"))
    say("\n", strrep("=", 78))
    say(label, "   (one informative bin: level analysis only)")
    say(strrep("=", 78))
    print(a, file = OUT); capture.output(print(a$anova_table), file = OUT, append = TRUE)
    return(invisible(a))
  }

  say("\n", strrep("=", 78)); say(label, "   (", nb, " bins)"); say(strrep("=", 78))

  a_level <- aov_ez("subj", "level", s, within = c("dur", "coh"))
  a_lin   <- aov_ez("subj", "lin",   s, within = c("dur", "coh"))
  say("\n-- LEVEL: duration, coherence, duration x coherence",
      "  (identical to the published effects)")
  capture.output(print(a_level$anova_table), file = OUT, append = TRUE)
  say("\n-- LINEAR trend: time, and its interactions")
  capture.output(print(a_lin$anova_table), file = OUT, append = TRUE)

  ## the trend against zero: a one-sample test on the participant means, which is
  ## the counterpart of the manuscript's main effect of time
  m0 <- s %>% group_by(subj) %>% summarise(v = mean(lin))
  tt <- t.test(m0$v)
  say(sprintf("\n   trend vs zero: %+.5f, t(%d) = %.2f, p = %.4g",
              mean(m0$v), tt$parameter, tt$statistic, tt$p.value))

  if (nb > 2) {
    a_quad <- aov_ez("subj", "quad", s, within = c("dur", "coh"))
    say("\n-- QUADRATIC component: curvature, and its interactions")
    capture.output(print(a_quad$anova_table), file = OUT, append = TRUE)
    q0 <- s %>% group_by(subj) %>% summarise(v = mean(quad))
    tq <- t.test(q0$v)
    say(sprintf("   curvature vs zero: %+.5f, t(%d) = %.2f, p = %.4g",
                mean(q0$v), tq$parameter, tq$statistic, tq$p.value))
  }

  if (!is.null(pub) && !any(is.na(pub))) {
    got <- a_level$anova_table$F
    ok <- all(abs(got - pub) <= pmax(0.004, 0.01 * abs(pub)))
    say(sprintf("\n   replication of published F: %s  [%s]",
                paste(sprintf("%.3f", pub), collapse = ", "),
                if (ok) "reproduced" else "DOES NOT REPRODUCE"))
  }

  ## (A) for comparison only: the split inside the analysis of variance, whose
  ## error term is pooled over all components and therefore assumes sphericity
  if (nb > 2) {
    d2 <- d %>% mutate(bin = factor(bin))
    contrasts(d2$bin) <- contr.poly(nlevels(d2$bin))
    m <- aov(y ~ dur * coh * bin + Error(subj / (dur * coh * bin)), data = d2)
    say("\n-- for comparison: split= inside aov(), pooled error, assumes sphericity")
    capture.output(
      print(summary(m, split = list(bin = list(linear = 1, quadratic = 2)))),
      file = OUT, append = TRUE)
  }
  invisible(list(level = a_level, lin = a_lin, scores = s))
}

## ---------------------------------------------------------------------------
results <- list()
for (i in seq_len(nrow(SPEC))) {
  p <- file.path(ARCHIVE, SPEC$file[i])
  if (!file.exists(p)) { say("missing: ", p); next }
  d <- read_long(p, SPEC$bins[[i]])
  results[[paste(SPEC$measure[i], SPEC$period[i])]] <-
    analyse_period(d, sprintf("%s, %s period", SPEC$measure[i], SPEC$period[i]),
                   SPEC$pub[[i]])
}

## ---------------------------------------------------------------------------
## Mu-beta lateralisation, stimulus window, resolved into two halves.
##
## Reported because the linear component over the full window is null while the
## published omnibus interaction is not: the coherence dependence of the slope is
## present in the first half and gone in the second, which is what saturation of
## the maintained level implies -- trajectories that have reached the internal
## threshold are pinned at a common level and their slope can no longer depend on
## coherence.  The quadratic component tests the same thing without choosing a
## cut-off and is the prespecified version; this split is descriptive, and
## choosing the cut-off after seeing the contrast would be a forking path.
##
## Sign convention: mu-beta lateralisation is negative-going with preparation, so
## a negative coherence contrast on the trend means a steeper buildup at higher
## coherence.

d <- read_long(file.path(ARCHIVE, "analysis_MBL/data/MBL_stim_JASP.csv"), 1:20)
say("\n", strrep("=", 78))
say("MBL, stimulus period, resolved into two halves (descriptive)")
say(strrep("=", 78))
for (h in list(list(1:10, "first half, 0.05-0.95 s"),
               list(11:20, "second half, 1.05-1.95 s"),
               list(1:20, "full window"))) {
  s <- d %>% filter(bin %in% h[[1]]) %>%
    mutate(bin = as.integer(factor(bin))) %>% make_scores()
  a <- aov_ez("subj", "lin", s, within = c("dur", "coh"))
  m0 <- s %>% group_by(subj) %>% summarise(v = mean(lin)); tt <- t.test(m0$v)
  A <- a$anova_table
  say(sprintf("  %-26s trend t = %5.2f (p = %.4f) | x coh F = %5.2f (p = %.4f) | x dur F = %5.2f (p = %.4f)",
              h[[2]], tt$statistic, tt$p.value,
              A["coh", "F"], A["coh", "Pr(>F)"], A["dur", "F"], A["dur", "Pr(>F)"]))
  ## cell means of the trend, for the direction of the effect
  say("      ", paste(sprintf("%s/%s %+.4f", s$dur, s$coh,
      (s %>% group_by(dur, coh) %>% summarise(m = mean(lin), .groups = "drop"))$m)[1:6],
      collapse = "  "))
}

## ---------------------------------------------------------------------------
## Poisson analyses of the partial-activation counts, delay window.
##
## The counts are a point process, so the trend is also estimated on the log
## scale.  Note that this is a different quantity from the linear contrast above:
## the contrast estimates d nu / dt, an additive rate of change, the Poisson slope
## estimates d log nu / dt, a multiplicative one.  They can disagree, and during
## the stimulus period they do, because the log slope divides by the level and the
## high-coherence cell has a much higher rate.  Neither is privileged there, since
## the model predicts no functional form during the stimulus; during the delay it
## predicts a log-linear one, which is why the Poisson analysis is restricted to
## that window.
##
## Three estimators are given.  They should agree, and disagreement would point to
## a misspecified random structure rather than to a substantive effect.

pf <- file.path(SIMDIR, "pma_counts.csv")
if (file.exists(pf)) {
  d <- read.csv(pf) %>% filter(period == "delay") %>%
    mutate(subj = factor(subj),
           dur  = factor(cell %/% 3, labels = c("0.3 s", "2 s")),
           coh  = factor(cell %% 3, labels = c("0%", "12%", "50%")),
           t    = (bin + 0.5) * 0.1 - 1.0,          # centred, seconds
           cohn = c(0, .12, .5)[cell %% 3 + 1] - mean(c(0, .12, .5)),
           durn = ifelse(cell >= 3, .5, -.5))

  say("\n", strrep("=", 78))
  say("Poisson analyses of the delay-period counts")
  say(strrep("=", 78))

  ## (1) two-stage: fit per participant and cell, then analyse the coefficients.
  ##     The second level supplies the standard errors, so the clustering of
  ##     upcrossings within a burst -- which makes the counts overdispersed
  ##     relative to Poisson -- does not bias inference.
  co <- d %>% group_by(subj, dur, coh) %>%
    group_modify(~{
      m <- glm(count ~ t + I(t^2), family = poisson,
               offset = log(ntrial), data = .x)
      tibble(slope = coef(m)[["t"]], curv = 2 * coef(m)[["I(t^2)"]])
    }) %>% ungroup()
  say("\n-- two-stage: per participant and cell, then repeated-measures ANOVA")
  capture.output(print(aov_ez("subj", "slope", co, within = c("dur", "coh"))$anova_table),
                 file = OUT, append = TRUE)
  capture.output(print(aov_ez("subj", "curv",  co, within = c("dur", "coh"))$anova_table),
                 file = OUT, append = TRUE)
  s0 <- co %>% group_by(subj) %>% summarise(v = mean(slope)); t0 <- t.test(s0$v)
  c0 <- co %>% group_by(subj) %>% summarise(v = mean(curv));  tc <- t.test(c0$v)
  say(sprintf("   slope vs zero: %+.4f, t(%d) = %.2f, p = %.4g",
              mean(s0$v), t0$parameter, t0$statistic, t0$p.value))
  say(sprintf("   curvature vs zero: %+.4f, t(%d) = %.2f, p = %.4g",
              mean(c0$v), tc$parameter, tc$statistic, tc$p.value))

  ## (2) one-stage Poisson mixed model with random slopes.  The random slope is
  ##     what makes the between-participant variability in the trend an estimated
  ##     variance component rather than the error term; without it the standard
  ##     error of the fixed slope is far too small.  An observation-level random
  ##     effect absorbs the overdispersion the clustering creates.
  d$obs <- factor(seq_len(nrow(d)))
  m1 <- glmer(count ~ t * durn + t * cohn + offset(log(ntrial)) +
                (1 + t | subj) + (1 | obs),
              family = poisson, data = d,
              control = glmerControl(optimizer = "bobyqa",
                                     optCtrl = list(maxfun = 4e5)))
  say("\n-- one-stage Poisson mixed model, random intercept and slope by participant")
  capture.output(print(summary(m1)$coefficients), file = OUT, append = TRUE)
  if (requireNamespace("performance", quietly = TRUE))
    capture.output(print(performance::check_overdispersion(m1)),
                   file = OUT, append = TRUE)

  ## (3) trends by cell, on the response scale, with the model above
  say("\n-- estimated trends by cell (emmeans)")
  capture.output(print(emtrends(m1, ~ durn * cohn, var = "t",
                                at = list(durn = c(-.5, .5),
                                          cohn = c(0, .12, .5) - mean(c(0, .12, .5))))),
                 file = OUT, append = TRUE)
}

## ---------------------------------------------------------------------------
## The same analyses on the simulated counts.
##
## The 22 simulated participants are equal groups of simulated trials.  The model
## has no between-participant variability, so the between-group variance is pure
## sampling noise and the simulated F values are not comparable in magnitude with
## the empirical ones.  Only the signs and the orderings are.

if (WITH_SIM) for (mdl in 1:2) {
  sf <- file.path(SIMDIR, sprintf("sim_counts_m%d.csv", mdl))
  if (!file.exists(sf)) next
  say("\n", strrep("=", 78)); say(sprintf("SIMULATION, Model %d", mdl))
  say(strrep("=", 78))
  ds <- read.csv(sf) %>%
    mutate(subj = factor(subj),
           dur = factor(cell %/% 3, labels = c("0.3 s", "2 s")),
           coh = factor(cell %% 3, labels = c("0%", "12%", "50%")))
  for (per in unique(ds$period)) {
    dd <- ds %>% filter(period == per) %>%
      transmute(subj, dur, coh, bin = bin + 1L, y = rate)
    analyse_period(dd, sprintf("Model %d, %s period", mdl, per))
  }
}

close(OUT)
cat(readLines("stats_pkg_tables.txt"), sep = "\n")

## ---------------------------------------------------------------------------
## VALUES TO CHECK AGAINST run_stats.R
##
##   PMA delay      duration      F(1, 21)     = 33.186    (published 33.19)
##                  coherence     F(1.96, 41)  =  3.361    (published  3.36)
##                  linear trend  F(1, 21)     = 35.238
##                  dur x linear  F(1, 21)     = 11.898
##                  coh x linear  F(1.70, 36)  =  0.524
##                  quadratic     F(1, 21)     = 18.891
##   PMA RS         all seven effects reproduce the published values exactly
##   PMA response   duration      F(1, 21)     =  7.613, p = .012   (one bin)
##   MBL stimulus   coh x linear  F(1.95, 41)  =  0.517, p = .596
##                  first half, trend x coherence  F = 5.76, p = .018
##   Poisson delay  slope +0.929, F(1, 21) = 102.95 ; curvature -0.253, p = .003
##   GEE/mixed      t = +0.84, t:durn = -0.179, t:cohn = -0.263, all p < .01
##
## Differences of a few per cent in the mixed-model coefficients are expected:
## the two-stage estimator weights participants equally, the mixed model weights
## them by precision.  A difference in sign or in significance would not be
## expected and would be worth investigating.
