# Analysis code for the theoretical note

Two languages, split by job.

**Python** owns the model: the stochastic simulation, the electromyographic detector, the
calibration, the parameter sweeps, the extraction of events from the archive, and the
figures.

**R** owns the statistics: every analysis of variance, every trend decomposition, and the
Poisson analyses of the partial-activation counts. The two sides meet at CSV files
written by `export_for_R.py`, which carry counts and exposures for the data and for each
fitted model, so that the identical statistical analysis runs on both sides.

Everything is reproducible from two inputs: the OSF archive (`86cbw`) and the manuscript.
No network access is needed.

```
python -c "import numpy, scipy, pandas, matplotlib"   # the whole Python dependency list
Rscript -e 'R.version.string'                         # base R only, for run_stats.R
```

`ARCHIVE` points at the unpacked archive (default `/home/claude/data`); `SIMDIR` at the
directory holding the CSV bridge files (default the parent of `R/`).

## Order of execution

```
python empirical.py               -> empirical.npz       extraction, checked against the archive
python targets.py                 -> targets.npz         calibration targets
python calibrate.py N M           -> fit_modelM.json     one chunk of N evaluations, model M
BLOCKS=behav python calibrate.py N M -> fitb_modelM.json behaviour-only fit
python export_for_R.py            -> pma_counts.csv      counts and exposures, empirical
                                     sim_counts_mM.csv   the same from each fitted model
Rscript R/run_stats.R --with-sim  -> stats_tables.txt    all tables, data and simulation
                                     stats_results.csv   one row per effect
Rscript R/emit_tex.R              -> _tables.tex         the same, for the note
python sweep.py N                 -> sweep_modelM.json   robustness and leak variants
python figures.py                 -> fig_*.pdf           the four figures of the note
python theory_checks.py                                  verification of Appendix A
python model1_bound.py                                   the Model 1 ceiling, Section 3
```

`calibrate.py` is chunked and resumable: each call runs a bounded number of evaluations,
writes the checkpoint, and picks up next time. Background processes do not survive
between sessions, which is why. `STEP` controls the restart simplex size
(`STEP=0.2 python calibrate.py 120 2`).

---

# Python

### `empirical.py`
Reads the segmented event files and the behavioural files and returns, per trial: the
condition, accuracy, response time, the times of stimulus onset and offset, of the
response signal, of the response, of the response burst, and every partial activation
with its offset.

Counting follows the archive's own `analysis_PMA/compute_PMA.py`: a partial activation is
an EMG onset in the channel of the responding effector occurring before the onset of the
response burst. Exclusions are responses before the signal, absent responses, and
response times under 0.2 s, leaving 20 566 trials.

**Do not re-merge the event list.** `myonset` applies the 25 ms merge when it defines the
activity windows, so the published events are already one per merged window. The
integrated-profile step then moves boundaries earlier, which is why 27% of consecutive
pairs are separated by less than 25 ms; it does not change the number of intervals.
Merging again removes about a quarter of the counts and is double counting.

### `targets.py`
Builds the target families for calibration, per participant and cell: accuracy, mean
response time and its interquartile range, mean and interquartile range of premotor and
motor execution time, delay and stimulus partial-activation rates, delay log-rate slope,
premature-response rate.

Dispersion uses the interquartile range, not the standard deviation. The empirical
premotor execution time has a long right tail -- 2.7% of trials over one second -- that
the model has no mechanism for, and scoring against the untrimmed standard deviation
forces the remaining parameters to manufacture variability elsewhere.

### `sim.py`
The model of Section 2 of the note, and the detector.

`simulate(p, c, D, n, model, seed, gamma)` integrates the equations at a 1 ms step and
returns the gated drive of the selected channel per trial. `model=1` sets the preparation
term to zero. `gamma` adds a leak common to both accumulators, for the reviewer's
sensitivity request.

`measures(sim)` applies the detection rules and returns accuracy, response time, premotor
and motor execution time, validity flags and the partial-activation event times.

`_bursts` is the detector, and reproduces `myonset` as it was used for the data:
threshold, merge intervals separated by at most 25 ms, then discard merged intervals with
fewer than `3 + f` supra-threshold samples, where `f` is the number of intervals per
second containing at most six. On the simulated drive the adaptive part is inert (`f` is
about 0.01/s) because the drive is smooth and has almost no short excursions; on real EMG
it does work, which biases the model towards over-counting by a few per cent, absorbed by
the gating parameter.

The integrated-profile refinement is not simulated: it moves boundaries but not their
number, and only the number is counted. For the same reason simulated burst durations are
not comparable with the reported ones and are not used.

### `calibrate.py`
Objective and search. `model_stats` runs the six cells and returns the target families;
`make_objective` divides each by the between-participant standard error of the target, so
one unit of error is one standard error. Parameters are searched in logarithmic
coordinates and clipped to the bounds in `LO`/`HI`.

Thirteen free parameters. `sigx` is fixed at 0.100 and fixes the amplitude unit. Three
combinations are weakly conditioned rather than unidentified, and are reported as
combinations: `lam * kappa`, `alpha = beta / Delta`, and `Lmotor + r / muRS`.

`BLOCKS=behav` restricts the criterion to accuracy, mean response time, its interquartile
range and the anticipation rate -- what a study without electromyography would see -- and
writes `fitb_modelM.json`. That is what the behavioural-indistinguishability section uses.

### `sweep.py`
Multiplies each free parameter by 0.5 and by 2 in turn, adds three leak rates, and records
whether each directional effect keeps the observed sign. Uses 150 trials per cell by
default, enough for level effects but not for slope differences -- the R16 column is
underpowered in the sweep and should be checked at the calibrated point with more trials.

### `export_for_R.py`
Writes the bridge files. `pma_counts.csv` has one row per participant, cell, period and
bin, with the raw count and the number of trials contributing to that bin;
`sim_counts_mM.csv` the same from each fitted model.

Exposure is not always the number of valid trials. A partial activation precedes the
response burst by definition, so once that burst has begun a trial can no longer
contribute and later bins are undefined rather than empty. This matters only in the
response-signal and response windows.

Simulated participants are 22 equal groups of simulated trials. This is not a claim that
the model has between-participant variability -- it has none -- but it lets the identical
R analysis run on both sides. The simulated between-group variance is pure sampling noise,
so simulated F values are not comparable in magnitude with the empirical ones; only signs
and orderings are.

### `figures.py`
The four figures of the note: the manuscript's Figure 1 simulated for both models, a
single trial with the detected intervals, the rate profiles against data, and the two
shape predictions.

### `theory_checks.py`
Verification of Appendix A against direct integration at a 1 ms step: the Kac-Rice
expression against a simulated count of upcrossings, the occupation identity against the
simulated time above the level, the ratio of merged clusters to raw upcrossings, and the
residual condition dependence of motor execution time from the filter transient.

The Euler bias on crossing counts is upward, about 2% at a 1 ms step and shrinking with
the step. It affects the simulated rate, not the direction of any effect.

### `model1_bound.py`
The two numbers behind the exclusion of Model 1 in Section 3 of the note.

`relaxation(kappa)` gives the fraction of the stationary variance reached one second after
commitment, which is what licenses the stationary form of the crossing rate everywhere in
the analysis window: a deficit of 1.3% at kappa = 2.3, one per cent at 2.4, and 5e-11 at
the fitted 12.8.

`best_slope(frac)` bounds the log-rate slope Model 1 can produce while reaching a given
fraction of the observed rate, **without any stationary approximation**. With alpha = 0
the rate depends on kappa and on the distance to the gate and on nothing else -- SD_eps
cancels -- so two observed quantities give two equations in two unknowns. At a quarter of
the observed rate the largest available slope is 0.004/s, against 0.700 observed.

This replaces an earlier argument from the ceiling `nu <= omega / 2pi`, which is the
alpha = 0 special case of the crossing rate and cannot be used to constrain kappa from
data generated with a ramp.

---

# R

### `R/rmanova.R`
The statistical machinery, in base R, because CRAN is unreachable from the analysis
container.

- `gg_epsilon(M)` -- Greenhouse-Geisser epsilon for a within factor with k levels, from
  the covariance matrix of the level means projected onto k-1 orthonormal contrasts.
- `rm_oneway(M)` -- one-way repeated-measures F with the subject by factor interaction as
  error, degrees of freedom multiplied by epsilon.
- `rm_paired(v)` -- a two-level factor, tested as a paired t on the difference score and
  reported as F = t^2, which needs no sphericity correction.
- `rm_twoway(X)` -- the 2 by 3 design: both main effects and the interaction.
- `poly_weights(k)`, `slope_weights(k, w)` -- orthogonal polynomial contrasts, and the
  rescaling that makes the linear component an ordinary least-squares slope in units per
  second.
- `pois_slope_subject()` -- per-participant, per-cell Poisson fit of
  `log nu(t) = b0 + b1 t + b2 t^2` with the trial count as offset.
- `pois_gee()` -- the one-stage alternative: a log-linear model over all participants with
  cluster-robust standard errors.

**Why the scores are computed before the ANOVA.** Keeping the bin factor and asking
`aov()` for `split = list(bin = list(linear = 1, quadratic = 2))` decomposes the numerator
but leaves the denominator pooled over all 19 components. That is valid only under
sphericity, and sphericity is badly violated here -- some published epsilons are below
0.1. Computing the score first gives each component its own error term, and a
one-degree-of-freedom contrast needs no correction.

**Why two components.** The linear because the model predicts a monotone ramp during the
delay; the quadratic because mu-beta lateralisation during the stimulus is non-monotone,
rising for a second and then flattening, so a linear contrast alone reports it as null.
Prespecified, applied identically to all three measures. No higher component.

### `R/run_stats.R`
Every test, on data and on simulation. Writes `stats_tables.txt` and `stats_results.csv`.
`--with-sim` adds the simulated counts if `export_for_R.py` has run.

Each entry in `SPEC` carries the file, the bin window, and the three published F values
that do not involve the bin factor, recomputed as a replication check. Eleven of the
twelve analyses reproduce to the last reported digit.

**The bin windows differ between files and this is easy to get wrong.** Partial
activations use bins 0-19 for the stimulus and 10-29 for the delay; the brain files are
offset by one, at 1-20 and 11-30. The two-bin windows: 0-1 for partial activations at the
signal, 1-2 at the response, 1-2 for both brain measures at the signal and the response
except the lateralised readiness potential at the response, which uses 0-1. These were
found by searching, for each file, the window reproducing all three published values at
once, which admits one solution. The wrong window reproduces nothing and gives no clue
why.

**Cell ordering.** The six cells are duration-major. R fills arrays column-major, so the
scores are built as `(n, coherence, duration)` and permuted. Getting this wrong leaves the
time effects correct -- they are grand means -- while scrambling duration and coherence,
which is a quiet and confusing failure.

**The response period is analysed on one bin.** In the corrected file the bin from -0.1 to
0 s is exactly zero for every participant and cell, because a partial activation precedes
the response burst by definition and the burst starts about 160 ms before the press. With
one bin empty, the level and trend scores are the same number up to a constant, so a
profile analysis would report three effects twice and would describe a slope resting on a
single point. The script detects a structurally empty bin and switches to a three-effect
level analysis; the switch is reported in the table header.

### `R/run_stats_pkg.R`
The same analyses written with the packages one would normally use: `afex` for the
repeated-measures ANOVA and Greenhouse-Geisser, `emmeans` for the trend contrasts and the
two-phase decomposition, `lme4` and `lmerTest` for the mixed models, `performance` for the
overdispersion check. It has never been run here, because CRAN is unreachable from the
container; it is the version to run on an ordinary machine, and the values to check
against are listed in a comment block at the end of the file.

Two things it adds. It computes the `split=` decomposition inside `aov()` alongside the
score-based one, so the difference between a pooled error term and a component-specific
one can be seen directly. And it fits the one-stage Poisson mixed model with random
intercept and slope by participant plus an observation-level random effect for
overdispersion, which is the proper version of the cluster-robust model that `rmanova.R`
implements by hand.

### `R/emit_tex.R`
Turns `stats_results.csv` into the LaTeX tables of the note, with the published value
beside each new one.

---

# Correspondence with the note

| note | script |
| --- | --- |
| Section 2, the model | `sim.py` |
| Section 3, predictions | derived by hand; checked by `theory_checks.py`, `model1_bound.py` |
| Section 4, from the process to the observable | `sim.py` (`_bursts`), `theory_checks.py` |
| Section 5, the data | `empirical.py` |
| Section 6, statistical re-analysis | `R/run_stats.R`, `R/emit_tex.R` |
| Section 7, corrected data | `R/run_stats.R` |
| Section 8, behaviour does not discriminate | `calibrate.py` with `BLOCKS=behav` |
| Section 9, simulations and calibration | `calibrate.py`, `sweep.py` |
| Figures | `figures.py` |
| Appendix, the rate | `theory_checks.py` |
| Section 3, exclusion of Model 1 | `model1_bound.py` |

---

# Things that will bite

**The container filesystem does not persist.** Scripts and the unpacked archive have to be
re-uploaded each session. Background processes do not survive between turns either.

**Two exported data files contained errors and were replaced.** The response-signal file
now reproduces the published values exactly; the response file changes a conclusion, the
duration main effect passing from p = .919 to p = .012. Anything computed before that
replacement should be regenerated.

**`min_samples` counts supra-threshold samples inside the merged interval**, not the
length of the interval. A merged interval built from two short blips passes.

**Sampling rate.** The recording is at 1024 Hz and the simulation at 1000 Hz, so three
samples means 2.9 ms in the data and 3 ms here. Immaterial at the current precision.

**The lateralised readiness potential during the stimulus** reproduces only to about 3%,
in the same direction on all three values. Every effect there is null before and after.

**The calibration is not certified global.** The search was restarted with progressively
larger simplices until the gain became marginal, but thirteen parameters with a stochastic
objective deserve more restarts than were run. The numbers in Section 9 should be
regenerated if the search is pushed further; the checkpoint makes that cheap.
