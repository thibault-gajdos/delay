## rmanova.R ----------------------------------------------------------------
##
## Repeated-measures analysis of variance for a fully within-subjects design with
## one observation per cell, written in base R so that the analyses have no
## package dependencies.  CRAN is not reachable from the analysis container, so
## afex / ez / lme4 are unavailable; everything below is implemented directly and
## validated against the published values of the manuscript (see check_replication
## at the bottom of run_stats.R).
##
## WHAT IS IMPLEMENTED
##
##   gg_epsilon(M)      Greenhouse-Geisser epsilon for a within factor with k
##                      levels, from the (nsub x k) matrix of level means.  The
##                      standard estimator
##
##                          eps = (tr S~)^2 / ((k-1) tr(S~ S~)),   S~ = C S C',
##
##                      with C an orthonormal basis of the k-1 contrasts among
##                      levels and S the covariance matrix of the level means
##                      across participants.  Equals 1 under sphericity and
##                      1/(k-1) in the worst case.
##
##   rm_oneway(M)       One-way repeated-measures F test on (nsub x k) data, with
##                      the subject x factor interaction as the error term, and
##                      the degrees of freedom multiplied by epsilon.  Returns
##                      df1, df2, F, p and partial eta squared.
##
##   rm_twoway(X)       Two-way (2 x 3) repeated-measures analysis on an
##                      (nsub x 2 x 3) array.  Returns the three effects:
##                      the two-level factor, tested as a paired t on the
##                      difference score (F = t^2, no sphericity issue); the
##                      three-level factor, on the means over the two-level
##                      factor; and their interaction, as a one-way analysis of
##                      the difference scores across the three levels.
##
##   poly_weights(k)    Orthogonal polynomial contrast weights on k equally
##                      spaced levels, the equivalent of contr.poly(k).  Column j
##                      is the polynomial component of degree j.
##
##   slope_weights(k,w) Weights giving the ordinary least-squares slope of the
##                      values against time, in units per second, for k bins of
##                      width w seconds.  Proportional to the first polynomial
##                      component, so F and p are identical; only the scale of
##                      the coefficient differs, and this scale is the one that
##                      can be reported as a rate of change.
##
## WHY THE SCORES ARE COMPUTED FIRST
##
## The alternative, keeping the bin factor and asking aov() for
## split = list(bin = list(linear = 1, quadratic = 2)), decomposes the numerator
## but leaves the denominator pooled over all 19 components of the bin factor.
## That test is valid only under sphericity, and sphericity is badly violated
## here: some Greenhouse-Geisser epsilons in the published tables are below 0.1.
## Computing the score first and analysing it as a dependent variable gives each
## component its own error term -- subject x linear for the linear component --
## and a one-degree-of-freedom contrast needs no sphericity correction at all.

gg_epsilon <- function(M) {
  k <- ncol(M)
  if (k < 3) return(1)
  ## orthonormal basis of the contrasts among the k levels
  C <- qr.Q(qr(cbind(1, contr.poly(k))))[, -1, drop = FALSE]
  C <- t(C)
  S <- cov(M)
  St <- C %*% S %*% t(C)
  as.numeric(sum(diag(St))^2 / ((k - 1) * sum(diag(St %*% St))))
}

rm_oneway <- function(M) {
  n <- nrow(M); k <- ncol(M)
  gm <- mean(M)
  ss_c <- n * sum((colMeans(M) - gm)^2)
  ss_s <- k * sum((rowMeans(M) - gm)^2)
  ss_e <- sum((M - gm)^2) - ss_c - ss_s
  df1 <- k - 1; df2 <- (k - 1) * (n - 1)
  Fv <- (ss_c / df1) / (ss_e / df2)
  e <- gg_epsilon(M)
  list(df1 = df1 * e, df2 = df2 * e, F = Fv,
       p = pf(Fv, df1 * e, df2 * e, lower.tail = FALSE),
       eta2p = ss_c / (ss_c + ss_e), eps = e)
}

rm_paired <- function(v) {
  ## one-sample test of a difference score; reported as F = t^2 on (1, n-1)
  n <- length(v); tt <- t.test(v)
  list(df1 = 1, df2 = n - 1, F = as.numeric(tt$statistic)^2, p = tt$p.value,
       eta2p = as.numeric(tt$statistic)^2 / (as.numeric(tt$statistic)^2 + n - 1),
       eps = 1)
}

rm_twoway <- function(X) {
  ## X: nsub x 2 x 3
  list(
    duration  = rm_paired(apply(X[, 2, ], 1, mean) - apply(X[, 1, ], 1, mean)),
    coherence = rm_oneway(apply(X, c(1, 3), mean)),
    interaction = rm_oneway(X[, 2, ] - X[, 1, ])
  )
}

poly_weights <- function(k) contr.poly(k)

slope_weights <- function(k, width = 0.1) {
  t <- (seq_len(k) - (k + 1) / 2) * width
  t / sum(t^2)
}

## ---------------------------------------------------------------------------
## Poisson analyses of the partial-activation counts.
##
## The counts are a point process, not a Gaussian measure, so the trend is also
## estimated on the log scale.  Two versions are provided, and they answer
## different questions:
##
##   pois_slope_subject()  fits log nu(t) = b0 + b1 t (+ b2 t^2) separately for
##                         each participant and cell by maximum likelihood, with
##                         the number of trials as an offset, and the resulting
##                         coefficients are then entered into the same
##                         repeated-measures analyses as any other score.  This
##                         is the two-stage approach: the second level supplies
##                         the standard errors, so clustering of upcrossings
##                         within a burst -- which makes the counts overdispersed
##                         relative to Poisson -- does not bias inference.
##
##   pois_gee()            fits a single log-linear model to all participants at
##                         once with cluster-robust standard errors, which is the
##                         one-stage alternative.  Provided as a check; it should
##                         and does agree with the two-stage result.
##
## Note that the Poisson slope estimates d log nu / dt, a multiplicative rate of
## change, whereas the linear contrast of the analysis of variance estimates
## d nu / dt, an additive one.  These are different quantities and can disagree;
## see the note for the case where they do.

pois_slope_subject <- function(y, offset_n, t, degree = 1) {
  ## y: counts in each bin; offset_n: number of trials; t: bin centres, centred
  X <- if (degree == 1) cbind(1, t) else cbind(1, t, t^2)
  fit <- try(glm.fit(X, y, family = poisson(),
                     offset = rep(log(offset_n), length(y))), silent = TRUE)
  if (inherits(fit, "try-error") || !fit$converged) return(rep(NA_real_, degree + 1))
  coef(fit)[seq_len(degree + 1)]
}

pois_gee <- function(df, formula, cluster) {
  ## working-independence Poisson GLM with cluster-robust (sandwich) covariance
  m <- glm(formula, family = poisson(), data = df)
  X <- model.matrix(m)
  mu <- fitted(m)
  r <- residuals(m, type = "response")
  bread <- solve(t(X) %*% (X * mu))
  meat <- matrix(0, ncol(X), ncol(X))
  for (g in unique(cluster)) {
    i <- which(cluster == g)
    u <- t(X[i, , drop = FALSE]) %*% r[i]
    meat <- meat + u %*% t(u)
  }
  V <- bread %*% meat %*% bread
  se <- sqrt(diag(V))
  z <- coef(m) / se
  data.frame(term = names(coef(m)), estimate = coef(m), se = se, z = z,
             p = 2 * pnorm(-abs(z)), row.names = NULL)
}
